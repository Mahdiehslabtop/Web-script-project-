/*==================== SHOW MENU ====================*/
// Get elements for the navigation menu, toggle button, and close button
const navMenu = document.getElementById("nav-menu"),
  navToggle = document.getElementById("nav-toggle"),
  navClose = document.getElementById("nav-close");

/*===== MENU SHOW =====*/
/* Validate if the toggle button exists */
if (navToggle) {
  navToggle.addEventListener("click", () => {
    // Add the 'show-menu' class to display the menu
    navMenu.classList.add("show-menu");
  });
}

/*===== MENU HIDDEN =====*/
/* Validate if the close button exists */
if (navClose) {
  navClose.addEventListener("click", () => {
    // Remove the 'show-menu' class to hide the menu
    navMenu.classList.remove("show-menu");
  });
}

/*==================== REMOVE MENU MOBILE ====================*/
// Get all navigation links
const navLink = document.querySelectorAll(".nav__link");

function linkAction() {
  // Remove the 'show-menu' class when a navigation link is clicked
  const navMenu = document.getElementById("nav-menu");
  navMenu.classList.remove("show-menu");
}
// Add click event listeners to each navigation link to trigger linkAction
navLink.forEach((n) => n.addEventListener("click", linkAction));

/*==================== CHANGE BACKGROUND HEADER ====================*/
function scrollHeader() {
  const header = document.getElementById("header");
  // Add the 'scroll-header' class to the header when the page is scrolled down 100px or more
  if (this.scrollY >= 100) header.classList.add("scroll-header");
  else header.classList.remove("scroll-header");
}
// Trigger scrollHeader when the window is scrolled
window.addEventListener("scroll", scrollHeader);

/*==================== SWIPER DISCOVER ====================*/
// Initialize the Swiper.js for the discover section
let swiper = new Swiper(".discover__container", {
  effect: "coverflow", // Apply coverflow effect to slides
  grabCursor: true, // Show a grab cursor when hovering over the slides
  centeredSlides: true, // Center slides in the swiper
  slidesPerView: "auto", // Set slides per view to auto
  loop: true, // Loop the slides infinitely
  spaceBetween: 32, // Set space between slides
  coverflowEffect: {
    rotate: 0, // Set the rotation of the coverflow effect to 0
  },
});

/*==================== VIDEO ====================*/
// Get elements for the video player, play/pause button, and icon
const videoFile = document.getElementById("video-file"),
  videoButton = document.getElementById("video-button"),
  videoIcon = document.getElementById("video-icon");

function playPause() {
  if (videoFile.paused) {
    // Play the video and change the icon to pause
    videoFile.play();
    videoIcon.classList.add("ri-pause-line");
    videoIcon.classList.remove("ri-play-line");
  } else {
    // Pause the video and change the icon to play
    videoFile.pause();
    videoIcon.classList.remove("ri-pause-line");
    videoIcon.classList.add("ri-play-line");
  }
}
// Add click event listener to the video button to trigger playPause
videoButton.addEventListener("click", playPause);

function finalVideo() {
  // Change the icon back to play when the video ends
  videoIcon.classList.remove("ri-pause-line");
  videoIcon.classList.add("ri-play-line");
}
// Add event listener for when the video ends to trigger finalVideo
videoFile.addEventListener("ended", finalVideo);

/*==================== SHOW SCROLL UP ====================*/
function scrollUp() {
  const scrollUp = document.getElementById("scroll-up");
  // Show the scroll-up button when scrolled down 200px or more
  if (this.scrollY >= 200) scrollUp.classList.add("show-scroll");
  else scrollUp.classList.remove("show-scroll");
}
// Trigger scrollUp when the window is scrolled
window.addEventListener("scroll", scrollUp);

/*==================== SCROLL SECTIONS ACTIVE LINK ====================*/
// Get all sections with an ID
const sections = document.querySelectorAll("section[id]");

function scrollActive() {
  const scrollY = window.pageYOffset;

  sections.forEach((current) => {
    const sectionHeight = current.offsetHeight; // Get height of current section
    const sectionTop = current.offsetTop - 50; // Get distance from top of the section
    sectionId = current.getAttribute("id"); // Get the section's ID

    // Add 'active-link' class to the nav link corresponding to the section in view
    if (scrollY > sectionTop && scrollY <= sectionTop + sectionHeight) {
      document
        .querySelector(".nav__menu a[href*=" + sectionId + "]")
        .classList.add("active-link");
    } else {
      // Remove 'active-link' class if the section is not in view
      document
        .querySelector(".nav__menu a[href*=" + sectionId + "]")
        .classList.remove("active-link");
    }
  });
}
// Trigger scrollActive when the window is scrolled
window.addEventListener("scroll", scrollActive);

/*==================== SCROLL REVEAL ANIMATION ====================*/
// Initialize ScrollReveal with custom options
const sr = ScrollReveal({
  distance: "60px", // Distance the elements move
  duration: 2800, // Duration of the animation
  // reset: true,       // Uncomment to reset animations on scroll
});

// Apply scroll reveal to specific elements with different origins
sr.reveal(
  `.home__data, .home__social-link, .home__info,
           .discover__container,
           .experience__data, .experience__overlay,
           .place__card,
           .sponsor__content,
           .footer__data, .footer__rights`,
  {
    origin: "top", // Animation starts from the top
    interval: 100, // Delay between each element's animation
  }
);

sr.reveal(
  `.about__data, 
           .video__description,
           .subscribe__description`,
  {
    origin: "left", // Animation starts from the left
  }
);

sr.reveal(
  `.about__img-overlay, 
           .video__content,
           .subscribe__form`,
  {
    origin: "right", // Animation starts from the right
    interval: 100, // Delay between each element's animation
  }
);

/*==================== DATEPICKER INITIALIZATION ====================*/
// Initialize jQuery UI datepicker on the input element with ID 'datepicker'
$(document).ready(function () {
  $("#datepicker").datepicker();
});

/*==================== DARK LIGHT THEME ====================*/
// Get elements for theme toggle button and define theme/icon class names
const themeButton = document.getElementById("theme-button");
const darkTheme = "dark-theme";
const iconTheme = "ri-sun-line";

// Get the user's previously selected theme and icon from localStorage
const selectedTheme = localStorage.getItem("selected-theme");
const selectedIcon = localStorage.getItem("selected-icon");

// Function to get the current theme
const getCurrentTheme = () =>
  document.body.classList.contains(darkTheme) ? "dark" : "light";
// Function to get the current icon
const getCurrentIcon = () =>
  themeButton.classList.contains(iconTheme) ? "ri-moon-line" : "ri-sun-line";

// Apply the previously selected theme and icon if available
if (selectedTheme) {
  document.body.classList[selectedTheme === "dark" ? "add" : "remove"](
    darkTheme
  );
  themeButton.classList[selectedIcon === "ri-moon-line" ? "add" : "remove"](
    iconTheme
  );
}

// Add event listener to the theme button to toggle dark/light theme
themeButton.addEventListener("click", () => {
  document.body.classList.toggle(darkTheme); // Toggle the dark theme class
  themeButton.classList.toggle(iconTheme); // Toggle the icon class

  // Save the user's selection in localStorage
  localStorage.setItem("selected-theme", getCurrentTheme());
  localStorage.setItem("selected-icon", getCurrentIcon());
});

/*==================== FORM VALIDATION ====================*/
// Initialize jQuery validation for the form with ID 'contactForm'
$(document).ready(function () {
  $("#contactForm").validate({
    rules: {
      name: {
        required: true, // Name field is required
        minlength: 2, // Name must be at least 2 characters long
      },
      email: {
        required: true, // Email field is required
        email: true, // Email must be in a valid format
      },
    },
    messages: {
      name: {
        required: "Please enter your name", // Custom message for name field
        minlength: "Your name must consist of at least 2 characters", // Custom message for minlength
      },
      email: "Please enter a valid email address", // Custom message for email field
    },
  });
});
